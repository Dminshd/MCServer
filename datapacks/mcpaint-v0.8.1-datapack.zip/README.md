# MC Paint
MC paint is a datapack for Minecraft 1.19.4 - 1.20.x that allows you to create custom paintings and place them anywhere in the world. There is also a required resource pack.

# Versions
The latest version is for Minecraft 1.20 - 1.20.1. Older versions can be found in the legacy repository: https://github.com/Eroxen/MC-Paint-legacy.

### For Minecraft 1.20.x
- (latest) Datapack Version 0.8 + Resource Pack Version 0.8
- Datapack Version 0.7, 0.7.1, or 0.7.2 + Resource Pack Version 0.7
### For Minecraft 1.19.4
- (latest) Datapack Version 0.6 + Resource Pack Version 0.6
- Datapack Version 0.5 + Resource Pack Version 0.5
- Datapack Version 0.4 + Resource Pack Version 0.4
- Datapack Version 0.3 + Resource Pack Version 0.3
- Datapack Version 0.2 + Resource Pack Version 0.2
- Datapack Version 0.1 + Resource Pack Version 0.1
